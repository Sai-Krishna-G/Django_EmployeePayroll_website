from django.contrib import admin
from .models import Employee,role,Department


# Register your models here.
admin.site.register(Employee)
admin.site.register(role)
admin.site.register(Department)